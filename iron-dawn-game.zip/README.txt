IRON DAWN: FIRST STRIKE
=======================
A desert-war FPS in the spirit of early-2000s RTS classics.

HOW TO PLAY
1. Extract this ZIP anywhere.
2. Double-click IronDawn-standalone.html — it opens in your browser
   (Chrome, Edge or Firefox recommended). No install needed.
3. Click DEPLOY.

CONTROLS
  WASD ......... Move          Mouse ....... Aim / Fire
  Shift ........ Sprint        Right Mouse . Aim down sights
  Space ........ Jump          R ........... Reload
  1 / 2 / 3 .... Weapons       G ........... Frag grenade
  C ............ Crouch        Esc ......... Pause

MISSION
Fight down the road to the Scorpion Cartel stronghold, destroy the
Stinger AA sites, blow the arms dealer's stockpile, then reach the
extraction smoke. Explosive barrels are your friends.

Full source: https://github.com/Fkk03/game
(branch claude/generals-zero-hour-fps-guu8sv, folder fps/)
