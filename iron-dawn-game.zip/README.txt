IRON DAWN: DESERT COMMAND
=========================
A real-time strategy skirmish in the spirit of early-2000s desert-war
RTS classics — base building, supply lines, tank columns, generals
powers and superweapons.

HOW TO PLAY
1. Extract this ZIP anywhere.
2. Double-click IronDawn-RTS-standalone.html (Chrome/Edge/Firefox).
   No install, no internet needed.
3. Pick your faction (Coalition or Scorpion Cartel), difficulty and
   starting funds, then COMMENCE OPERATION.

BASICS
  Left-drag ........ select forces      Right-click ..... move / attack
  WASD & screen edge  scroll            Wheel ........... zoom
  Q / E ............ rotate camera      Ctrl+1-9 ........ control groups
  A + click ........ attack-move        S ............... stop
  H ................ jump to base       . (period) ...... idle worker
  Tab (hold) ....... battle stats       F1 .............. field manual

GETTING STARTED
- Select your dozer/worker, build a Reactor (Coalition) then Barracks,
  then a Supply Center NEAR THE CRATE DOCK north of your base.
- Build supply trucks — they haul crates automatically. Money wins wars.
- War Factory -> tanks. Capture oil derricks with infantry for income.
- Earn promotions, unlock airstrikes, race the enemy superweapon.
- Destroy every enemy structure to win.

BONUS: IronDawn-FPS-bonus.html — a first-person spin-off set in the
same desert war (WASD + mouse, blow up the cartel stronghold).

Full source: https://github.com/Fkk03/game
(branch claude/generals-zero-hour-fps-guu8sv: rts/ and fps/)
